package ca.carleton.sysc5801.sim4j;

public interface MetricFunction
{
  double getMetric(Link link);
}
